import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;


public class Q2 {
    public static void parta() throws FileNotFoundException {
        File fd=new File("src/cree.txt");
        Scanner sc1=new Scanner(fd);
        ArrayList<String> lines=new ArrayList<>();
        //ArrayList<String> userData=new ArrayList<>();
        String [][]userdata= new String[10][2];
        String []user = new String[0];
        int count=0;
        Boolean f=false;

        while(sc1.hasNext())
        {
            String line=sc1.nextLine();
            lines.add(line);
        }

        for(int i=0;i<lines.size();i++)
        {
            // System.out.println(lines.get(i));
            user=lines.get(i).split(" ");
            count+= user.length;
           // userdata[i][0]=user[0];
            //userdata[i][1]=user[1];
        }

        System.out.println("Count is \t"+count);



    }
    public static void partb(String data) throws IOException {
        String data1= "nice";
        File fd=new File("src/cred.txt");
        Scanner sc1=new Scanner(fd);
        File fd1=new File("src/newfile.txt");
        FileWriter fr1=new FileWriter(fd1);
        ArrayList<String> lines=new ArrayList<>();
        ArrayList<String> lines1=new ArrayList<>();
        //ArrayList<String> userData=new ArrayList<>();
        String []user = new String[0];
        int count=0;
        Boolean f=false;

        while(sc1.hasNext())
        {
            String line=sc1.nextLine();
            lines.add(line);
        }
        StringBuilder line= new StringBuilder();
        System.out.println("Data Before Updation is\n");

        for(int k=0;k<lines.size();k++)
        {
            System.out.println(lines.get(k));
        }
        System.out.println("Data after updation\n");
        for(int i=0;i<lines.size();i++)
        {
            // System.out.println(lines.get(i));
            user=lines.get(i).split(" ");

           for(int j=0;j< user.length;j++)
           {
               if(Objects.equals(user[j], data))
               {
                  // System.out.println("Data Matched\n"+user[j]);
                   user[j]=data1;
               }
                line.append(user[j]).append(" ");

           }
            System.out.println(line);
           lines1.add(String.valueOf(line));
           fr1.write(line.toString());
           line = new StringBuilder();

        }
        for(int k=0;k<lines1.size();k++)
        {
            fr1.write(lines1.get(k).toString());
            fr1.flush();
        }


    }
    public static void main(String[] args) throws IOException {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1 for part (a)\nEnter 2 for part(b)\n");
        int choice= sc.nextInt();
        if(choice==1)
        {
            parta();

        }
        else if(choice==2)
        {
            Scanner sc1=new Scanner(System.in);
            System.out.println("Enter word to search");
            String word=sc1.nextLine();
            partb(word);


        }
        else {
            return ;
        }


    }
}
