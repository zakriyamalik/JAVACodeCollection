import java.io.*;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;
import java.util.Scanner;
// Unble to figure out the path of Dir files in PC o put it in the folder of code But the implemented logic wil work

public class Q1 {
    Q1()
    {

    }
    public static void showlogger(int u_id, String f_name,String operation) throws IOException {
        Scanner sc2=new Scanner(System.in);
        File f=new File("src/logger.txt");
        FileWriter fr=new FileWriter(f,true);
        CurrentDateTimeExample1 date1=new CurrentDateTimeExample1();
        String date=date1.rdate();

       String data=u_id+" "+f_name+" "+operation+" "+date+"\n";
        System.out.println("Logger Data is\n"+data);
        fr.write(data);


    }
    public static void showNext(int id) throws IOException {
        ArrayList<String> lines=new ArrayList<>();
        //ArrayList<String> userData=new ArrayList<>();
        String [][]userdata= new String[10][2];
        String []user;
        Scanner sc2=new Scanner(System.in);
        System.out.println("Enter 1 for qwe\nEnter 2 for sad\nEnter 3 to exit\n");
        int choice=sc2.nextInt();
        sc2.nextLine();
        if(choice==1)
        {
            System.out.println("Enter 1 to read qwe\nEnter 2 to write in qwe\nEnter 3 to exit\n");
             choice=sc2.nextInt();
            sc2.nextLine();
            if(choice==1)
            {
                File f=new File("src/dirfile/qwe.txt");
                Scanner sc3=new Scanner(f);
                while(sc3.hasNext())
                {
                    String line=sc3.nextLine();
                    lines.add(line);



                }

                System.out.println("data is\n");
                for(int i=0;i<lines.size();i++)
                {
                    // System.out.println(lines.get(i));
                    user=lines.get(i).split(" ");
                    userdata[i][0]=user[0];
                    userdata[i][1]=user[1];
                    System.out.println(lines.get(i));


                }
                showlogger(id,"qwe.txt","read");
            }
            else if(choice==2)
            {
                File f=new File("/dirfile/qwe.txt");
                FileWriter fr=new FileWriter(f,true);
                System.out.println("Enter data to write");
                String data=sc2.nextLine();
                System.out.println("Data is\n"+data);
                fr.write(data);
                showlogger(id,"qwe.txt","write");

            }
            else
            {
                return;
            }

        }
        else if(choice==2)
        {

            System.out.println("Enter 1 to read sad\nEnter 2 to write in sad\nEnter 3 to exit\n");
            choice=sc2.nextInt();
            sc2.nextLine();
            if(choice==1)
            {
                File f=new File("src/dirfile/sad.txt");
                Scanner sc3=new Scanner(f);
                while(sc3.hasNext())
                {
                    String line=sc3.nextLine();
                    lines.add(line);



                }

                System.out.println("data is\n");
                for(int i=0;i<lines.size();i++)
                {
                    // System.out.println(lines.get(i));
                    user=lines.get(i).split(" ");
                    userdata[i][0]=user[0];
                    userdata[i][1]=user[1];
                    System.out.println(lines.get(i));

                }
                showlogger(id,"sad.txt","read");
            }
            else if(choice==2)
            {
                File f=new File("/dir/sad.txt");
                FileWriter fr=new FileWriter(f,true);
                System.out.println("Enter data to write");
                String data=sc2.nextLine();
                System.out.println("Data is\n"+data);
                fr.write(data);
                showlogger(id,"sad.txt","write");

            }
            else
            {
                return;
            }


        }
        else
        {
            return;
        }

    }


    public static void main(String[] args) throws IOException {
        Validate v=new Validate();
        Scanner sc1=new Scanner(System.in);
        System.out.println("Enter ID:");
        int id=sc1.nextInt();
        sc1.nextLine();

        System.out.println("Enter Password");
        String pass=sc1.nextLine();
       boolean flage= v.validate(id,pass);

    }
}
