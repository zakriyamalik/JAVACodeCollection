import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class Validate {
    public static boolean validate(int id, String pass) throws IOException {
        // BufferedReader br=new BufferedReader(new FileReader("cree.txt"));
        File fd=new File("src/cred.txt");
        Scanner sc1=new Scanner(fd);
        ArrayList<String> lines=new ArrayList<>();
        //ArrayList<String> userData=new ArrayList<>();
        String [][]userdata= new String[10][2];
        String []user;
        int count=0;
        Boolean f=false;

        while(sc1.hasNext())
        {
            String line=sc1.nextLine();
            lines.add(line);



        }

        System.out.println("data is\n");
        for(int i=0;i<lines.size();i++)
        {
            // System.out.println(lines.get(i));
            user=lines.get(i).split(" ");
            userdata[i][0]=user[0];
            userdata[i][1]=user[1];
            System.out.println(userdata[i][0]+" "+userdata[i][1]);
            if(Objects.equals(userdata[i][1], pass))
            {
                f=true;

            }

        }
        if(f)
        {
            Q1.showNext(id);
        }
        else
        {
            System.out.println("User not found\n");
        }

        return true;
    }

}
