import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
public class CurrentDateTimeExample1 {
    String date;
    CurrentDateTimeExample1()
    {
        DateTimeFormatter dtf =
                DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String date="";
        System.out.println(dtf.format(now));
        date=dtf.format(now);
        //rdate(date);
        this.date=date;
    }

    public String rdate()
    {
        return this.date;

    }
}